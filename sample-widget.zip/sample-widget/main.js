let artifacts = [];
const attribute = RM.Data.Attributes.PRIMARY_TEXT;
const button = document.getElementById('button');

// Clear selected artifacts on load
RM.Client.setSelection(artifacts);

// Subscribe to event for selection of artifacts
RM.Event.subscribe(RM.Event.ARTIFACT_SELECTED, async (selectedArtifacts) => {
  artifacts = selectedArtifacts;
});

// Add Click listener to button
button.addEventListener('click', () => {
  updateArtifacts();
});

export function updateArtifacts() {
  console.info('Update of artifacts started.');

  RM.Data.getAttributes(artifacts, attribute, function(result) {
    // Store any required attribute changes here
    let toSave = [];

    // Go through artifact data examining primary text values
    result.data.forEach(function(item) {
      const currentValue = item.values[attribute];

      item.values[attribute] = currentValue + ' (This value was updated)';

      toSave.push(item);
    });

    // Perform a bulk save for all changed attributes
    RM.Data.setAttributes(toSave, function(result) {
      if (result.code !== RM.OperationResult.OPERATION_OK) {
        console.error('Could not save artifacts.');
      } else {
        console.log('Saved artifacts successfully.');
      }
    });
  });
}